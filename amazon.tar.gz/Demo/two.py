def generalizedGDC(num, arr):
    prev_gcd = arr[0]
    if num > 2:
        arr_slice = arr[1:]
        prev_gcd = generalizedGDC(num - 1, arr_slice)
    else:
        if num == 2:
            prev_gcd = arr[1]
    return find_gcd(arr[0], prev_gcd)

def find_gcd(x, y):
    while(y):
        x, y = y, x % y
    return x

print(generalizedGDC(5, [2, 3, 4, 5,6]))
print(generalizedGDC(5, [2, 4, 6, 8, 10]))
print(generalizedGDC(2, [6, 6]))
print(generalizedGDC(1, [6]))
print(generalizedGDC(5, [2, 4, 10, 8, 6]))
print(generalizedGDC(3, [15, 20, 10]))
