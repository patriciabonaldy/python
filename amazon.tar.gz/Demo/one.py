ACTIVE = 1
INACTIVE = 0

def cellComplete(states, days):
    new_states = []
    if days > 1:
        states = cellComplete(states, days - 1)
    len_states = len(states)
    for index in range(len_states):
        if index > 0 and index < len_states - 1:         # Caso general, es un valor del medio
            new_states.append(calculate_new_state(states[index - 1], states[index + 1]))
        else:
            if len_states != 1:
                if index == 0:                            # Caso particular, es extremo izquierdo
                    new_states.append(calculate_new_state(INACTIVE, states[index + 1]))
                else:                                     # derecho
                    new_states.append(calculate_new_state(states[index - 1], INACTIVE))
            else:                                         # Caso particular, tiene un solo valor
                new_states.append(calculate_new_state(INACTIVE, INACTIVE))

    return new_states

def calculate_new_state(left, right):
    if (left == ACTIVE and right == ACTIVE) or (left == INACTIVE and right == INACTIVE):
        return INACTIVE
    return ACTIVE

print(cellComplete([1, 0, 0, 0, 0, 1, 0, 0], 1))
print(cellComplete([1, 1, 1, 0, 1, 1, 1, 1], 2))


