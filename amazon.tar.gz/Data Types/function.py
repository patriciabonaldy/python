def greeting(language): 
    if language=='eng': 
        return 'hello world'
    elif language =='fr':
        return 'Bonjour le monde'
    else: return  'language not supported'

l = [greeting('eng'), greeting('fr'), greeting('ger')]
print(l[1])

#
def callf(f):
    lang = 'eng'
    return f(lang)

print(callf(greeting))

#
list = [1, 2, 3, 4]
for item in map(lambda n: n*2, list):
    print(item)

#
for item in filter(lambda n: n < 4, list):
    print(item)

#
words = str.split('The longest word in the sentence')
print(sorted(words, key=len))

#
sl = ['A', 'b', 'a', 'C', 'c']
sl.sort(key = str.lower)
print(sl)
sl.sort()
print(sl)

#
items = [['rice', 2.4, 8], ['flour', 1.9, 5], ['corn', 4.7, 6]]
items.sort(key = lambda item: item[1])
print(items)