s = '0123456789'
l = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
m = [11, 12, 13, 14, 15]

print(list(s))
l.append(10)
print(l)
l.extend(m)
print(l)
print(l.count(5))
print(l.index(5))
l.insert(16, len(l))
print(l)
l.pop(len(l) - 1)
print(l)
l.remove(15)
print(l)
l.reverse()
print(l)
l.sort()
print(l)
n = m
m[1] = 21
print(n)
print(m)
o = [i*2 for i in l]
print(o)
words = 'here is a sentence'
z = [[word, len(word)] for word in words.split()]
print(z)