import networkx as nx
import matplotlib.pyplot as plt
import matplotlib.image as mpimg

G = nx.Graph()
G.add_edge('A', 'B', weight=1)
G.add_edge('A', 'S', weight=1)
G.add_edge('B', 'A', weight=1)
G.add_edge('S', 'A', weight=1)
G.add_edge('S', 'G', weight=1)
G.add_edge('S', 'C', weight=1)
G.add_edge('D', 'C', weight=1)
G.add_edge('G', 'S', weight=1)
G.add_edge('G', 'F', weight=1)
G.add_edge('G', 'H', weight=1)
G.add_edge('H', 'G', weight=1)
G.add_edge('H', 'E', weight=1)
G.add_edge('E', 'C', weight=1)
G.add_edge('E', 'H', weight=1)
G.add_edge('F', 'C', weight=1)
G.add_edge('F', 'G', weight=1)
G.add_edge('C', 'D', weight=1)
G.add_edge('C', 'S', weight=1)
G.add_edge('C', 'E', weight=1)
G.add_edge('C', 'F', weight=1)

nx.shortest_path(G, 'A', 'D', weight='weight')

pos=nx.spring_layout(G)
nx.draw(G, with_labels=True)

plt.savefig('save.png')
